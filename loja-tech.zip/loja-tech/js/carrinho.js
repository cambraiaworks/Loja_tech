class ItemCarrinho {
  constructor(produto, quantidade) {
    this.produto = produto
    this.quantidade = quantidade
  }

  calcularSubtotal() {
    let sub = this.produto.preco * this.quantidade
    return sub
  }

  subtotalFormatado() {
    return formatarMoeda(this.calcularSubtotal())
  }
}

class Carrinho {
  constructor() {
    this.itens = []
    this.taxaDesconto1 = 0.10
    this.taxaDesconto2 = 0.15
    this.msgDesconto1 = '10% de desconto para compras acima de R$ 300,00!'
    this.msgDesconto2 = '15% de desconto especial para compras acima de R$ 500,00!'
  }

  adicionarItem(produto, quantidade) {
    if (produto.estaDisponivel() == false) {
      return {sucesso: false, mensagem: 'Produto sem estoque.'}
    }

    let achou = null
    let i = 0
    while (i < this.itens.length) {
      if (this.itens[i].produto.codigo == produto.codigo) {
        achou = this.itens[i]
        break
      }
      i++
    }

    if (achou != null) {
      let novaQtd = achou.quantidade + quantidade
      if (novaQtd > produto.estoque) {
        return {sucesso: false, mensagem: 'Estoque insuficiente. Disponível: ' + produto.estoque + ' unidade(s).'}
      }
      achou.quantidade = novaQtd
    } else {
      if (quantidade > produto.estoque) {
        return {sucesso: false, mensagem: 'Estoque insuficiente. Disponível: ' + produto.estoque + ' unidade(s).'}
      }
      let novoItem = new ItemCarrinho(produto, quantidade)
      this.itens.push(novoItem)
    }

    return {sucesso: true, mensagem: 'Produto adicionado!'}
  }

  removerItem(codigo) {
    for (let i = 0; i < this.itens.length; i++) {
      if (this.itens[i].produto.codigo == codigo) {
        this.itens.splice(i, 1)
        return true
      }
    }
    return false
  }

  alterarQuantidade(codigo, novaQtd) {
    for (let i = 0; i < this.itens.length; i++) {
      if (this.itens[i].produto.codigo == codigo) {
        if (novaQtd <= 0) {
          this.itens.splice(i, 1)
          return {sucesso: true, removido: true}
        }
        if (novaQtd > this.itens[i].produto.estoque) {
          return {sucesso: false, mensagem: 'Estoque máximo: ' + this.itens[i].produto.estoque + ' unidade(s).'}
        }
        this.itens[i].quantidade = novaQtd
        return {sucesso: true, removido: false}
      }
    }
    return {sucesso: false, mensagem: 'Item não encontrado.'}
  }

  calcularSubtotal() {
    let total = 0
    for (let i = 0; i < this.itens.length; i++) {
      total += this.itens[i].calcularSubtotal()
    }
    return total
  }

  calcularTotalItens() {
    let qtd = 0
    let i = 0
    while (i < this.itens.length) {
      qtd = qtd + this.itens[i].quantidade
      i++
    }
    return qtd
  }

  calcularDesconto() {
    let sub = this.calcularSubtotal()
    let taxa = 0
    let msg = ''

    if (sub >= 500) {
      taxa = this.taxaDesconto2
      msg = this.msgDesconto2
    } else if (sub >= 300) {
      taxa = this.taxaDesconto1
      msg = this.msgDesconto1
    } else {
      taxa = 0
      msg = ''
    }

    return {valor: sub * taxa, taxa: taxa, mensagem: msg}
  }

  calcularTotal() {
    let sub = this.calcularSubtotal()
    let desc = this.calcularDesconto()
    return sub - desc.valor
  }

  estaVazio() {
    if (this.itens.length == 0) {
      return true
    }
    return false
  }

  limpar() {
    this.itens = []
  }

  obterResumo() {
    let sub = this.calcularSubtotal()
    let desc = this.calcularDesconto()
    let total = sub - desc.valor

    return {
      itens: this.itens,
      totalItens: this.calcularTotalItens(),
      subtotal: sub,
      desconto: desc,
      total: total
    }
  }

}

const carrinho = new Carrinho()
