function formatarMoeda(valor) {
  let totalCentavos = Math.round(valor * 100)
  let reais = Math.floor(totalCentavos / 100)
  let centavos = totalCentavos % 100

  let centavosTexto = ''
  if (centavos < 10) {
    centavosTexto = '0' + centavos
  } else {
    centavosTexto = '' + centavos
  }

  let reaisTexto = '' + reais
  let reaisFormatado = ''
  let contador = 0

  for (let i = reaisTexto.length - 1; i >= 0; i--) {
    reaisFormatado = reaisTexto[i] + reaisFormatado
    contador++
    if (contador % 3 == 0 && i != 0) {
      reaisFormatado = '.' + reaisFormatado
    }
  }

  return 'R$ ' + reaisFormatado + ',' + centavosTexto
}

class Produto {
  constructor(codigo, nome, categoria, preco, estoque, imagem) {
    this.codigo = codigo
    this.nome = nome
    this.categoria = categoria
    this.preco = preco
    this.estoque = estoque
    this.imagem = imagem
  }

  estaDisponivel() {
    if (this.estoque > 0) {
      return true
    } else {
      return false
    }
  }

  precoFormatado() {
    return formatarMoeda(this.preco)
  }
}

const produtos = [
  new Produto(1, 'Notebook UltraSlim Pro 15"', 'Notebooks', 3799.99, 5,
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&q=80'),

  new Produto(2, 'Notebook Gamer FireEdge', 'Notebooks', 6499.90, 3,
    'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=400&q=80'),

  new Produto(3, 'Mouse Óptico Precision X', 'Periféricos', 149.90, 20,
    'https://images.unsplash.com/photo-1527814050087-3793815479db?w=400&q=80'),

  new Produto(4, 'Teclado Mecânico RGB StrikeKeys', 'Periféricos', 389.90, 8,
    'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400&q=80'),

  new Produto(5, 'Headset Gamer SoundBlast 7.1', 'Games', 279.90, 12,
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80'),

  new Produto(6, 'Controle Gamepad Pro Wireless', 'Games', 319.90, 0,
    'https://images.unsplash.com/photo-1592840496694-26d035b52b48?w=400&q=80'),

  new Produto(7, 'Webcam Full HD 1080p AutoFocus', 'Acessórios', 229.90, 15,
    'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=400&q=80'),

  new Produto(8, 'Hub USB-C 7 em 1 TechConnect', 'Acessórios', 189.90, 10,
    'https://images.unsplash.com/photo-1625723044792-44de16ccb4e9?w=400&q=80')
]
