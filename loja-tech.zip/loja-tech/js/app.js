var grid = document.getElementById('produtosGrid')
var badge = document.getElementById('carrinhoBadge')
var btnAbrirCart = document.getElementById('btnAbrirCarrinho')
var btnFecharCart = document.getElementById('btnFecharCarrinho')
var painelCart = document.getElementById('painelCarrinho')
var overlay = document.getElementById('overlay')
var cartItens = document.getElementById('carrinhoItens')
var cartVazio = document.getElementById('carrinhoVazio')
var spanTotalItens = document.getElementById('totalItens')
var spanSubtotal = document.getElementById('subtotal')
var spanDesconto = document.getElementById('desconto')
var spanFinal = document.getElementById('valorFinal')
var spanDescInfo = document.getElementById('descontoInfo')
var btnFinalizar = document.getElementById('btnFinalizar')
var campoBusca = document.getElementById('campoBusca')
var divFiltros = document.getElementById('filtros')
var msgSemResultado = document.getElementById('msgSemResultado')
var modalOverlay = document.getElementById('modalOverlay')
var modalBody = document.getElementById('modalBody')
var modalTitulo = document.getElementById('modalTitulo')
var btnFecharModal = document.getElementById('btnFecharModal')
var btnCancelar = document.getElementById('btnCancelarModal')
var btnConfirmar = document.getElementById('btnConfirmarCompra')
var sucessoOverlay = document.getElementById('modalSucessoOverlay')
var msgSucesso = document.getElementById('msgSucesso')
var btnFecharSucesso = document.getElementById('btnFecharSucesso')

let categoriaAtiva = 'Todos'
let termoBusca = ''

const mostrarProdutos = (lista) => {
  grid.innerHTML = ''

  if (lista.length == 0) {
    msgSemResultado.classList.remove('escondido')
    return
  }

  msgSemResultado.classList.add('escondido')

  for (let i = 0; i < lista.length; i++) {
    let p = lista[i]
    let disponivel = p.estaDisponivel()
    let classeCard = disponivel ? 'card' : 'card indisponivel'
    let textoDisp = disponivel ? '✔ Em estoque (' + p.estoque + ' un.)' : '✖ Indisponível'
    let classeDisp = disponivel ? 'card-disponibilidade disponivel' : 'card-disponibilidade indisponivel'
    let textoBotao = disponivel ? 'Adicionar ao Carrinho' : 'Sem Estoque'

    let card = document.createElement('div')
    card.className = classeCard

    card.innerHTML =
      '<img class="card-img" src="' + p.imagem + '" alt="' + p.nome + '" loading="lazy">' +
      '<div class="card-corpo">' +
        '<span class="card-categoria">' + p.categoria + '</span>' +
        '<h3 class="card-nome">' + p.nome + '</h3>' +
        '<p class="card-preco">' + p.precoFormatado() + '</p>' +
        '<p class="' + classeDisp + '">' + textoDisp + '</p>' +
        '<button class="btn-adicionar" ' + (disponivel ? '' : 'disabled') + '>' + textoBotao + '</button>' +
      '</div>'

    let btn = card.querySelector('.btn-adicionar')
    if (disponivel) {
      btn.addEventListener('click', function() {
        adicionarProduto(p.codigo)
      })
    }

    grid.appendChild(card)
  }
}

function filtrar() {
  let lista = []

  for (let i = 0; i < produtos.length; i++) {
    let p = produtos[i]
    let okCategoria = false
    let okBusca = false

    if (categoriaAtiva == 'Todos' || p.categoria == categoriaAtiva) {
      okCategoria = true
    }

    if (p.nome.toLowerCase().indexOf(termoBusca.toLowerCase()) != -1) {
      okBusca = true
    }

    if (okCategoria && okBusca) {
      lista.push(p)
    }
  }

  mostrarProdutos(lista)
}

function adicionarProduto(codigo) {
  let prod = null
  let i = 0
  while (i < produtos.length) {
    if (produtos[i].codigo == codigo) {
      prod = produtos[i]
      break
    }
    i++
  }

  if (prod == null) return

  let res = carrinho.adicionarItem(prod, 1)

  if (res.sucesso) {
    atualizarCarrinho()
  } else {
    mostrarAviso(res.mensagem, 'erro')
  }
}

function atualizarCarrinho() {
  let resumo = carrinho.obterResumo()

  badge.textContent = resumo.totalItens
  spanTotalItens.textContent = resumo.totalItens
  spanSubtotal.textContent = formatarMoeda(resumo.subtotal)
  spanDesconto.textContent = formatarMoeda(resumo.desconto.valor)
  spanFinal.textContent = formatarMoeda(resumo.total)
  spanDescInfo.textContent = resumo.desconto.mensagem

  cartItens.innerHTML = ''

  if (carrinho.estaVazio()) {
    cartVazio.classList.remove('escondido')
    cartItens.appendChild(cartVazio)
    return
  }

  cartVazio.classList.add('escondido')

  for (let i = 0; i < resumo.itens.length; i++) {
    let item = resumo.itens[i]
    let el = montarItemCarrinho(item)
    cartItens.appendChild(el)
  }
}

const montarItemCarrinho = (item) => {
  let div = document.createElement('div')
  div.className = 'item-carrinho'

  div.innerHTML =
    '<p class="item-nome">' + item.produto.nome + '</p>' +
    '<p class="item-preco-unit">Preço unitário: ' + item.produto.precoFormatado() + '</p>' +
    '<div class="item-controles">' +
      '<div class="item-quantidade">' +
        '<button class="btn-qty btn-menos">−</button>' +
        '<span class="qty-valor">' + item.quantidade + '</span>' +
        '<button class="btn-qty btn-mais">+</button>' +
      '</div>' +
      '<span class="item-subtotal">' + item.subtotalFormatado() + '</span>' +
    '</div>' +
    '<button class="btn-remover">🗑 Remover</button>'

  div.querySelector('.btn-menos').addEventListener('click', function() {
    let res = carrinho.alterarQuantidade(item.produto.codigo, item.quantidade - 1)
    if (res.sucesso) {
      atualizarCarrinho()
      filtrar()
    }
  })

  div.querySelector('.btn-mais').addEventListener('click', function() {
    let res = carrinho.alterarQuantidade(item.produto.codigo, item.quantidade + 1)
    if (res.sucesso == false) {
      mostrarAviso(res.mensagem, 'erro')
    } else {
      atualizarCarrinho()
      filtrar()
    }
  })

  div.querySelector('.btn-remover').addEventListener('click', function() {
    carrinho.removerItem(item.produto.codigo)
    atualizarCarrinho()
    filtrar()
  })

  return div
}

function abrirCarrinho() {
  painelCart.classList.remove('escondido')
  overlay.classList.remove('escondido')
  document.body.style.overflow = 'hidden'
}

function fecharCarrinho() {
  painelCart.classList.add('escondido')
  overlay.classList.add('escondido')
  document.body.style.overflow = ''
}

function abrirResumo() {
  if (carrinho.estaVazio()) {
    mostrarAviso('Carrinho vazio! Adicione algum produto antes de finalizar.', 'erro')
    return
  }

  let resumo = carrinho.obterResumo()
  modalBody.innerHTML = ''
  modalTitulo.textContent = 'Resumo do Pedido'

  for (let i = 0; i < resumo.itens.length; i++) {
    let item = resumo.itens[i]
    let linha = document.createElement('div')
    linha.className = 'modal-item'
    linha.innerHTML =
      '<span class="modal-item-nome">' + item.produto.nome + '</span>' +
      '<span class="modal-item-qty">x' + item.quantidade + '</span>' +
      '<span class="modal-item-sub">' + item.subtotalFormatado() + '</span>'
    modalBody.appendChild(linha)
  }

  let divRes = document.createElement('div')
  divRes.className = 'modal-resumo'
  divRes.innerHTML =
    '<div class="modal-resumo-linha"><span>Total de itens:</span><span>' + resumo.totalItens + '</span></div>' +
    '<div class="modal-resumo-linha"><span>Subtotal:</span><span>' + formatarMoeda(resumo.subtotal) + '</span></div>' +
    '<div class="modal-resumo-linha desconto"><span>Desconto:</span><span>− ' + formatarMoeda(resumo.desconto.valor) + '</span></div>' +
    '<div class="modal-resumo-linha total"><span>Valor final:</span><span>' + formatarMoeda(resumo.total) + '</span></div>'

  modalBody.appendChild(divRes)
  modalOverlay.classList.remove('escondido')
  document.body.style.overflow = 'hidden'
}

function fecharModal() {
  modalOverlay.classList.add('escondido')
  document.body.style.overflow = ''
}

function confirmarCompra() {
  let resumo = carrinho.obterResumo()
  let totalFmt = formatarMoeda(resumo.total)
  let qtd = resumo.totalItens

  fecharModal()
  fecharCarrinho()
  carrinho.limpar()
  atualizarCarrinho()
  filtrar()

  msgSucesso.textContent = 'Pedido confirmado! ' + qtd + ' item(s) no valor de ' + totalFmt + '. Obrigado por comprar na Nexvion Tech!'
  sucessoOverlay.classList.remove('escondido')
  document.body.style.overflow = 'hidden'
}

function fecharSucesso() {
  sucessoOverlay.classList.add('escondido')
  document.body.style.overflow = ''
}

let avisoAtual = null

function mostrarAviso(msg, tipo) {
  if (avisoAtual != null) {
    document.body.removeChild(avisoAtual)
    avisoAtual = null
  }

  let aviso = document.createElement('div')
  aviso.textContent = msg + '  (clique para fechar)'
  let cor = '#ff4d6d'
  if (tipo != 'erro') {
    cor = '#43e97b'
  }
  aviso.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:' + cor + ';color:#fff;padding:12px 24px;border-radius:50px;font-weight:600;font-size:0.9rem;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,0.3);white-space:nowrap;cursor:pointer;'

  aviso.addEventListener('click', function() {
    document.body.removeChild(aviso)
    avisoAtual = null
  })

  document.body.appendChild(aviso)
  avisoAtual = aviso
}

btnAbrirCart.addEventListener('click', abrirCarrinho)
btnFecharCart.addEventListener('click', fecharCarrinho)
overlay.addEventListener('click', fecharCarrinho)
btnFinalizar.addEventListener('click', abrirResumo)
btnFecharModal.addEventListener('click', fecharModal)
btnCancelar.addEventListener('click', fecharModal)
btnConfirmar.addEventListener('click', confirmarCompra)
btnFecharSucesso.addEventListener('click', fecharSucesso)

campoBusca.addEventListener('input', function() {
  termoBusca = this.value
  filtrar()
})

let botoesFiltro = divFiltros.querySelectorAll('.btn-filtro')

for (let i = 0; i < botoesFiltro.length; i++) {
  botoesFiltro[i].addEventListener('click', function() {
    for (let j = 0; j < botoesFiltro.length; j++) {
      botoesFiltro[j].classList.remove('ativo')
    }

    this.classList.add('ativo')
    categoriaAtiva = this.getAttribute('data-categoria')
    filtrar()
  })
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    if (!sucessoOverlay.classList.contains('escondido')) {
      fecharSucesso()
    } else if (!modalOverlay.classList.contains('escondido')) {
      fecharModal()
    } else if (!painelCart.classList.contains('escondido')) {
      fecharCarrinho()
    }
  }
})

filtrar()
atualizarCarrinho()
